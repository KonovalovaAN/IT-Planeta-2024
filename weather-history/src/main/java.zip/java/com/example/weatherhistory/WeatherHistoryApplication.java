package com.example.weatherhistory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherHistoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeatherHistoryApplication.class, args);
	}

}
